

<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="card col-md-8" style="padding: 16px;">
        <div class="card-body">
            <h4 class="card-title"><?php echo e(__('message.research_project_detail')); ?></h4>
            <p class="card-description"><?php echo e(__('message.research_project_info')); ?></p>
            <div class="row">
                <p class="card-text col-sm-3"><b><?php echo e(__('message.project_name')); ?></b></p>
                <p class="card-text col-sm-9"><?php echo e($researchProject->project_name); ?></p>
            </div>
            <div class="row">
                <p class="card-text col-sm-3"><b><?php echo e(__('message.start_date')); ?></b></p>
                <p class="card-text col-sm-9"><?php echo e($researchProject->project_start); ?></p>
            </div>
            <div class="row">
                <p class="card-text col-sm-3"><b><?php echo e(__('message.end_date')); ?></b></p>
                <p class="card-text col-sm-9"><?php echo e($researchProject->project_end); ?></p>
            </div>
            <div class="row">
                <p class="card-text col-sm-3"><b><?php echo e(__('message.fund_source')); ?></b></p>
                <p class="card-text col-sm-9"><?php echo e($researchProject->fund->fund_name); ?></p>
            </div>
            <div class="row">
                <p class="card-text col-sm-3"><b><?php echo e(__('message.budget')); ?></b></p>
                <p class="card-text col-sm-9"><?php echo e($researchProject->budget); ?></p>
            </div>
            <div class="row">
                <p class="card-text col-sm-3"><b><?php echo e(__('message.project_details')); ?></b></p>
                <p class="card-text col-sm-9"><?php echo e($researchProject->note); ?></p>
            </div>
            <div class="row">
                <p class="card-text col-sm-3"><b><?php echo e(__('message.status')); ?></b></p>
                <?php if($researchProject->status == 1): ?>
                <p class="card-text col-sm-9"><?php echo e(__('message.status_submitted')); ?></p>
                <?php elseif($researchProject->status == 2): ?>
                <p class="card-text col-sm-9"><?php echo e(__('message.status_in_progress')); ?></p>
                <?php else: ?>
                <p class="card-text col-sm-9"><?php echo e(__('message.status_closed')); ?></p>
                <?php endif; ?>
            </div>
            
            <div class="row">
                <p class="card-text col-sm-3"><b><?php echo e(__('message.project_responsible')); ?></b></p>
                <?php $__currentLoopData = $researchProject->user; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php if($user->pivot->role == 1): ?>
                <p class="card-text col-sm-9">
                <?php if(App::getLocale() == 'th'): ?>
                    <?php echo e($user->position_th); ?><?php echo e($user->fname_th); ?> <?php echo e($user->lname_th); ?>

                <?php elseif(App::getLocale() == 'en' || App::getLocale() == 'cn'): ?>
                    <?php echo e($user->position_en); ?><?php echo e($user->fname_en); ?> <?php echo e($user->lname_en); ?>

                <?php endif; ?>
                </p>
              <?php endif; ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
            <div class="row">
                <p class="card-text col-sm-3"><b><?php echo e(__('message.project_members')); ?></b></p>
                <?php $__currentLoopData = $researchProject->user; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php if($user->pivot->role == 2): ?>
                        <p class="card-text col-sm-9">
                            <?php if(App::getLocale() == 'th'): ?>
                                <?php echo e($user->position_th); ?><?php echo e($user->fname_th); ?> <?php echo e($user->lname_th); ?>

                            <?php elseif(App::getLocale() == 'en' || App::getLocale() == 'cn'): ?>
                                <?php echo e($user->position_en); ?><?php echo e($user->fname_en); ?> <?php echo e($user->lname_en); ?>

                            <?php endif; ?>
                            <?php if(!$loop->last): ?>,<?php endif; ?>
                        </p>
                    <?php endif; ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php $__currentLoopData = $researchProject->outsider; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php if($user->pivot->role == 2): ?>
                        ,<?php if(App::getLocale() == 'th'): ?>
                            <?php echo e($user->title_name); ?><?php echo e($user->fname); ?> <?php echo e($user->lname); ?>

                        <?php elseif(App::getLocale() == 'en' || App::getLocale() == 'cn'): ?>
                            <?php echo e($user->title_name_en); ?><?php echo e($user->fname_en); ?> <?php echo e($user->lname_en); ?>

                        <?php endif; ?>
                        <?php if(!$loop->last): ?>,<?php endif; ?>
                    <?php endif; ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
            <div class="pull-right mt-5">
                <a class="btn btn-primary" href="<?php echo e(route('researchProjects.index')); ?>"><?php echo e(__('message.back')); ?></a>
            </div>

        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('dashboards.users.layouts.user-dash-layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/resources/views/research_projects/show.blade.php ENDPATH**/ ?>