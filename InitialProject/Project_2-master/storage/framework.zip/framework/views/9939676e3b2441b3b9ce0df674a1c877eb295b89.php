

<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="card col-md-8" style="padding: 16px;">
        <div class="card-body">
            <h4 class="card-title"><?php echo e(__('message.fund_detail')); ?></h4>
            <p class="card-description"><?php echo e(__('message.fund_details_info')); ?></p>

            <div class="row">
                <p class="card-text col-sm-3"><b><?php echo e(__('message.fund_name_label')); ?></b></p>
                <p class="card-text col-sm-9"><?php echo e($fund->fund_name); ?></p>
            </div>
            <div class="row">
                <p class="card-text col-sm-3"><b><?php echo e(__('message.year')); ?></b></p>
                <p class="card-text col-sm-9"><?php echo e($fund->fund_year); ?></p>
            </div>
            <div class="row">
                <p class="card-text col-sm-3"><b><?php echo e(__('message.fund_details')); ?></b></p>
                <p class="card-text col-sm-9"><?php echo e($fund->fund_details); ?></p>
            </div>
            <div class="row">
                <p class="card-text col-sm-3"><b><?php echo e(__('message.fund_type_label')); ?></b></p>
                <p class="card-text col-sm-9"><?php echo e($fund->fund_type); ?></p>
            </div>
            <div class="row">
                <p class="card-text col-sm-3"><b><?php echo e(__('message.fund_level_label')); ?></b></p>
                <p class="card-text col-sm-9"><?php echo e($fund->fund_level); ?></p>
            </div>
            <div class="row">
                <p class="card-text col-sm-3"><b><?php echo e(__('message.support_resource_label')); ?></b></p>
                <p class="card-text col-sm-9"><?php echo e($fund->support_resource); ?></p>
            </div>
            <div class="row">
                <p class="card-text col-sm-3"><b><?php echo e(__('message.added_by')); ?></b></p>
                 <?php
                    $lang = app()->getLocale();
                ?>
                <p class="card-text col-sm-9">
                    <?php if($lang === 'th'): ?>
                        <?php echo e($fund->user->fname_th); ?> <?php echo e($fund->user->lname_th); ?>

                    <?php else: ?>
                        <?php echo e($fund->user->fname_en); ?> <?php echo e($fund->user->lname_en); ?>

                    <?php endif; ?>
                </p>
            </div>

            <div class="pull-right mt-5">
                <a class="btn btn-primary btn-sm" href="<?php echo e(route('funds.index')); ?>"><?php echo e(__('message.back')); ?></a>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('dashboards.users.layouts.user-dash-layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/resources/views/funds/show.blade.php ENDPATH**/ ?>